<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel 7 PDF Example</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <button id="btn-export" class="btn btn-primary" onclick="exportHTML();">Export to
            word doc</button>
    </div>
    <div class="container mt-5" id="source-html">
        <h2 class="text-center mb-3"><center>Report Buku Tamu</center></h2>

        <table border="1">
            <thead style="background-color: #000; color:#fff">
                <tr>
                    <th>#</th>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Necessity</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->date); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->address); ?></td>
                    <td><?php echo e($item->necessity); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

    <div class="content-footer">

    </div>


    <script>
        function exportHTML(){
           var header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' "+
                "xmlns:w='urn:schemas-microsoft-com:office:word' "+
                "xmlns='http://www.w3.org/TR/REC-html40'>"+
                "<head><meta charset='utf-8'><title>Export HTML to Word Document with JavaScript</title></head><body>";
           var footer = "</body></html>";
           var sourceHTML = header+document.getElementById("source-html").innerHTML+footer;

           var source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(sourceHTML);
           var fileDownload = document.createElement("a");
           document.body.appendChild(fileDownload);
           fileDownload.href = source;
           fileDownload.download = 'Buku-Tamu.doc';
           fileDownload.click();
           document.body.removeChild(fileDownload);
        }
    </script>
</body>

</html>
<?php /**PATH D:\Project\Website\buku-tamu\resources\views/pages/dashboard/guest/print-word.blade.php ENDPATH**/ ?>